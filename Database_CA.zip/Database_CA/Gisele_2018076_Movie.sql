-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 52.50.23.197    Database: Gisele_2018076
-- ------------------------------------------------------
-- Server version	5.7.34-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Movie`
--

DROP TABLE IF EXISTS `Movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Movie` (
  `movieCod` int(11) DEFAULT NULL,
  `movieTitle` varchar(255) DEFAULT NULL,
  `movieDescription` varchar(255) DEFAULT NULL,
  `moviePrice` float DEFAULT NULL,
  `movieGenre` varchar(255) DEFAULT NULL,
  `movieStatus` tinyint(1) DEFAULT NULL,
  `moviePic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Movie`
--

LOCK TABLES `Movie` WRITE;
/*!40000 ALTER TABLE `Movie` DISABLE KEYS */;
INSERT INTO `Movie` VALUES (1,'American Beauty','comedy-drama film written by Alan Ball and directed by Sam Mendes. Kevin Spacey stars as Lester Burnham, an advertising executive who has a midlife crisis when he becomes infatuated with his teenage daughters best friendvalue',2.99,'comedy-drama',0,'american_beauty.jpg'),(2,'Avatar','American epic science fiction film directed, written, produced, and co-edited by James Cameron',2.99,'fiction',0,'avatar.jpg'),(3,'Euro Trip','When Scott and his high school lover break up after graduation, he travels to Europe to search for his pen pal, Mieke, after angering her',2.99,'comedy',0,'eurotrip.jpg'),(4,'Gone With The Wind','American classic in which a manipulative woman and a roguish man carry on a turbulent love affair in the American south during the Civil War and Reconstruction',2.99,'classic',0,'gone_with_the_wind.jpg'),(5,'Jurassic Park','American science fiction action film directed by Steven Spielberg and produced by Kathleen Kennedy and Gerald R. Molen',2.99,'science-fiction',0,'jurassic_park.jpg'),(6,'Matrix','Thomas Anderson, a computer programmer, is led to fight an underground war against powerful computers who have constructed his entire reality with a system called the Matrix.',2.99,'science-fiction',0,'matrix.jpg'),(7,'The Irishman','In the 1950s, truck driver Frank Sheeran gets involved with Russell Bufalino and his Pennsylvania crime family.',2.99,'crime',0,'the_irishman.jpg'),(8,'Toy Story','Toy Story is a 1995 American computer-animated buddy-adventure smash hit directed by John Lasseter',2.99,'animated',0,'toy_story.jpg'),(9,'Twelve Years a Slave','Solomon Northup, a free African-American, is promised a fortnightly job by Brown and Hamilton. However, after arriving in Washington DC, he realises that he has been sold into slavery',2.99,'drama',0,'twelve_years_a_slaver.jpg'),(10,'Zombieland','After a virus turns most people into zombies, the worlds surviving humans remain locked in an ongoing battle against the hungry undead',2.99,'comedy',0,'zombieland.jpg');
/*!40000 ALTER TABLE `Movie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-15 21:42:41
