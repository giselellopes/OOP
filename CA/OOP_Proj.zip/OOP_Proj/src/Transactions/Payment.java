/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Transactions;

/**
 *
 * @author Home
 */
public class Payment {
    
    protected int cardNumber;
    protected int cvv;
    protected String cardName;
    protected String email;
    protected Boolean firstRent;
    
    public Payment(){
            
        }

    public Payment(int cardNumber, int cvv, String email, Boolean firstRent) {
        this.cardNumber = cardNumber;
        this.cvv = cvv;
        this.email = email;
        this.firstRent = firstRent;
        
        
    }

    public int getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(int cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getFirstRent() {
        return firstRent;
    }

    public void setFirstRent(Boolean firstRent) {
        this.firstRent = firstRent;
    }

     
}
