/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Transactions;

/**
 *
 * @author Home
 */
public class Rent {
    
    private int dateRent;
    int dateReturn;
    private int dateNextBill;
    private double totalPrice;
    
    public Rent(){
        
    }
    
    public Rent(int dateRent, int dateReturn, int dateNextBill, double totalPrice){
        this.dateRent = dateRent;
        this.dateReturn = dateReturn;
        this.dateNextBill = dateNextBill;
        this.totalPrice = totalPrice;
    }

    public int getDateRent() {
        return dateRent;
    }

    public void setDateRent(int dateRent) {
        this.dateRent = dateRent;
    }

    public int getDateReturn() {
        return dateReturn;
    }

    public void setDateReturn(int dateReturn) {
        this.dateReturn = dateReturn;
    }

    public int getDateNextBill() {
        return dateNextBill;
    }

    public void setDateNextBill(int dateNextBill) {
        this.dateNextBill = dateNextBill;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    
    
}
