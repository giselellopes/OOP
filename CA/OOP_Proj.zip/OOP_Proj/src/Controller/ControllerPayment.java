/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import static Controller.Controller.getMovieDatabase;
import FrontEnd.FirstScreem;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Home
 */
public class ControllerPayment {
    
        FirstScreem firstscreen;
        Connection connection = null; //manages the connection 
        Statement statement = null; //instruction sql//instruction sql//instruction sql//instruction sql//instruction sql//instruction sql//instruction sql//instruction sql
        private Object conn;

        public ControllerPayment(){
            //this.payment = getPaymentView();
            this.firstscreen = new FirstScreem();
        }
        
        
        public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()) {
                case "click1":
                    setPaymentDatabase();
                    break;
                default:
                    System.out.println(e.getActionCommand());
                    break;
        }
    }
 
            
        try static {
            String dbServer = "jdbc:mysql://apontejaj.com:3306/Gisele_2018076?useSSL=false";
            String user = "Gisele_2018076";
            String password = "2018076";
            String query = "INSERT INTO Customer_Data(cardName, cardNumber, email)\n" + "VALUES (cardName, cardNumber, email);";
            Connection conn;

            try {
                conn = DriverManager.getConnection(dbServer, user, password);
            } catch (SQLException ex) {
                Logger.getLogger(ControllerPayment.class.getName()).log(Level.SEVERE, null, ex);
            }
                } catch (SQLException ex) {
                Logger.getLogger(ControllerPayment.class.getName()).log(Level.SEVERE, null, ex);
        }

      // create the java statement
      Statement st = conn.createStatement();
      
      // execute the query, and get a java resultset
      rsCustomer = st.executeQuery(query);
     
      // iterate through the java resultset
      while (rsCustomer.next())
      {
          
        int cardNumber = rsCustomer.setInteger("cardNumber");
        String cardName = rsCustomer.setString("cardName");
        String email = rsCustomer.setString("email");
        
       
      st.close();
    }
    catch (Exception e)
    {
      System.err.println("Got an exception! ");
      System.err.println(e.getMessage());
    }
}
    
}
