/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_proj;

import Controller.Controller;
import FrontEnd.FirstScreem;

/**
 *
 * @author Home
 */
public class OOP_Proj {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
    //Minh Van Truong
        new Controller();
       
        
        
    }
    
}
